import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../cubit/profile_cubit.dart';
import '../cubit/profile_state.dart';
import '../widgets/section_label.dart';
import '../widgets/settings_tile.dart';

/// Reached from the "App Settings" tile. Expects a `ProfileCubit` to
/// already be provided above it — see the `BlocProvider.value` wrapping
/// where this page is pushed from `ProfilePage`.
///
/// Language and Voice Guidance are real, Firestore-backed preferences
/// (`UserProfile.preferredLanguage` / `voiceEnabled`, already wired
/// through `ProfileRepository.updatePreferences`). Theme is UI-only for
/// now: there's no `ThemeMode` plumbed into the app's `MaterialApp` yet,
/// so the selection is saved locally (so it isn't just a visual) but
/// doesn't change the app's actual appearance until that wiring exists.
class AppSettingsPage extends StatelessWidget {
  const AppSettingsPage({super.key});

  static const Color primaryGreen = Color(0xFF1E5B3D);

  static const _languages = [
    _LanguageOption(code: 'en', label: 'English'),
    _LanguageOption(code: 'ar', label: 'العربية (Arabic)'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF6F8F7),
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: Colors.black87,
        title: const Text(
          'App Settings',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 17,
            color: Colors.black87,
          ),
        ),
      ),
      body: BlocBuilder<ProfileCubit, ProfileState>(
        builder: (context, state) {
          final profile = state.profile;
          if (profile == null) {
            return const Center(child: CircularProgressIndicator());
          }
          final cubit = context.read<ProfileCubit>();
          final currentLanguage = _languages.firstWhere(
            (l) => l.code == profile.preferredLanguage,
            orElse: () => _languages.first,
          );

          return SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
              children: [
                const SectionLabel('Language & Voice'),
                SettingsTile(
                  icon: Icons.translate_rounded,
                  iconColor: const Color(0xFF4C6FE0),
                  iconBg: const Color(0xFFEAEEFD),
                  title: 'App Language',
                  subtitle: currentLanguage.label,
                  onTap: () =>
                      _pickLanguage(context, cubit, profile.preferredLanguage),
                ),
                SettingsTile(
                  icon: Icons.record_voice_over_rounded,
                  iconColor: primaryGreen,
                  iconBg: const Color(0xFFEAF3EE),
                  title: 'Voice Guidance',
                  subtitle: profile.voiceEnabled
                      ? 'Spoken turn-by-turn is on'
                      : 'Off',
                  trailing: Switch(
                    value: profile.voiceEnabled,
                    activeColor: primaryGreen,
                    // onChanged: (value) => cubit.updatePreferences(voiceEnabled: value),
                    onChanged: (value) {},
                  ),
                  onTap: () {},
                  // onTap: () => cubit.updatePreferences(voiceEnabled: !profile.voiceEnabled),
                ),
                const SectionLabel('Appearance'),
                const _ThemeTile(),
              ],
            ),
          );
        },
      ),
    );
  }

  void _pickLanguage(
    BuildContext context,
    ProfileCubit cubit,
    String currentCode,
  ) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, 4),
                child: Text(
                  'App Language',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
              ),
              ..._languages.map(
                (lang) => RadioListTile<String>(
                  value: lang.code,
                  groupValue: currentCode,
                  activeColor: primaryGreen,
                  title: Text(lang.label),
                  onChanged: (valur) {},
                  // onChanged: (value) {
                  //   if (value != null) cubit.updatePreferences(preferredLanguage: value);
                  //   Navigator.of(sheetContext).pop();
                  // },
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }
}

class _LanguageOption {
  const _LanguageOption({required this.code, required this.label});
  final String code;
  final String label;
}

/// Local-only theme preference — see the class doc comment above for why
/// this doesn't touch Firestore or the app's actual ThemeMode yet.
class _ThemeTile extends StatefulWidget {
  const _ThemeTile();

  @override
  State<_ThemeTile> createState() => _ThemeTileState();
}

class _ThemeTileState extends State<_ThemeTile> {
  static const Color primaryGreen = Color(0xFF1E5B3D);
  static const _prefsKey = 'app_theme_preference';
  static const _options = ['System', 'Light', 'Dark'];

  String _selected = 'System';
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _selected = prefs.getString(_prefsKey) ?? 'System';
      _loaded = true;
    });
  }

  Future<void> _select(String value) async {
    setState(() => _selected = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, value);
    // TODO: once the app has a root ThemeMode (e.g. a ValueNotifier<ThemeMode>
    // read by MaterialApp), apply it here too — right now this only
    // remembers the choice, it doesn't change how the app looks.
  }

  @override
  Widget build(BuildContext context) {
    return SettingsTile(
      icon: Icons.dark_mode_outlined,
      iconColor: Colors.grey[700]!,
      iconBg: const Color(0xFFF1F3F2),
      title: 'Theme',
      subtitle: _loaded ? _selected : 'Loading…',
      onTap: () => _openPicker(context),
    );
  }

  void _openPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, 4),
                child: Text(
                  'Theme',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
              ),
              ..._options.map(
                (option) => RadioListTile<String>(
                  value: option,
                  groupValue: _selected,
                  activeColor: primaryGreen,
                  title: Text(option),
                  onChanged: (value) {
                    if (value != null) _select(value);
                    Navigator.of(sheetContext).pop();
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }
}

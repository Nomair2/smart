import 'package:MasarKKU/features/notification/presentation/widgets/notification_alert.dart';
import 'package:equatable/equatable.dart';

class NotificationsState extends Equatable {
  const NotificationsState({this.alerts = const []});

  final List<NotificationAlert> alerts;

  int get unreadCount => alerts.where((a) => a.isUnread).length;

  NotificationsState copyWith({List<NotificationAlert>? alerts}) {
    return NotificationsState(alerts: alerts ?? this.alerts);
  }

  @override
  List<Object?> get props => [alerts];
}

import 'package:MasarKKU/features/notification/presentation/widgets/notification_alert.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'notifications_state.dart';

/// Manages the alert list in memory, seeded with placeholder content.
/// `markAllAsRead` / `markAsRead` / `dismiss` all work today since
/// they're pure local-state operations — there's just nothing persisting
/// them across app restarts yet (no repository to write back to).
class NotificationsCubit extends Cubit<NotificationsState> {
  NotificationsCubit() : super(NotificationsState(alerts: _seed));

  static final List<NotificationAlert> _seed = [
    NotificationAlert(
      id: '1',
      category: AlertCategory.heatAlert,
      title: 'Extreme Heat Warning',
      message:
          'Temperature at KKU Campus is now 42°C. Smart Path recommends '
          'using shaded routes only. Avoid walking between 12PM–3PM.',
      timestamp: DateTime.now().subtract(const Duration(minutes: 5)),
    ),
    NotificationAlert(
      id: '2',
      category: AlertCategory.routeUpdate,
      title: 'Route Change: Gate 2 Path',
      message:
          'Construction on the east walkway near Gate 2 is affecting '
          'your saved route. A new optimized path has been generated.',
      timestamp: DateTime.now().subtract(const Duration(minutes: 23)),
    ),
    NotificationAlert(
      id: '3',
      category: AlertCategory.system,
      title: 'Season Mode Auto-Updated',
      message:
          'Smart Path detected a temperature rise and switched '
          'navigation to Summer Mode automatically for optimal comfort.',
      timestamp: DateTime.now().subtract(const Duration(hours: 1)),
    ),
    NotificationAlert(
      id: '4',
      category: AlertCategory.weather,
      title: 'Partly Cloudy This Afternoon',
      message:
          'Cloud cover expected between 3PM and 6PM. Sun exposure on '
          'campus routes will decrease. Winter Mode may become preferable.',
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      isUnread: false,
    ),
    NotificationAlert(
      id: '5',
      category: AlertCategory.savedRoute,
      title: 'Reminder: Saved Route',
      message:
          'Your usual route "Gate 1 → CS Building" is ready. Today\'s '
          'conditions: 38°C, 72% shade on recommended path.',
      timestamp: DateTime.now().subtract(const Duration(days: 1)),
      isUnread: false,
    ),
    NotificationAlert(
      id: '6',
      category: AlertCategory.newFeature,
      title: 'Voice Guidance Now Available',
      message:
          'Smart Path now supports Arabic and English voice-guided '
          'navigation. Enable it in Settings → Navigation → Voice Guidance.',
      timestamp: DateTime.now().subtract(const Duration(days: 2)),
      isUnread: false,
    ),
  ];

  void markAllAsRead() {
    emit(
      state.copyWith(
        alerts: state.alerts.map((a) => a.copyWith(isUnread: false)).toList(),
      ),
    );
  }

  void markAsRead(String id) {
    emit(
      state.copyWith(
        alerts: [
          for (final a in state.alerts)
            if (a.id == id) a.copyWith(isUnread: false) else a,
        ],
      ),
    );
  }

  void dismiss(String id) {
    emit(
      state.copyWith(alerts: state.alerts.where((a) => a.id != id).toList()),
    );
  }
}

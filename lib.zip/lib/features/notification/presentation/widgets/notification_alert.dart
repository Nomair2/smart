/// The only domain-layer file in this delivery — the presentation layer
/// needs something to type against. No repository/Firestore mapping
/// here yet (there's no notifications backend in this app so far, per
/// the earlier "once the notifications feature exists" TODO); this is
/// just the shape. Swap it for your real entity if you already have
/// one, or ask for the data layer (a `NotificationsRepository` streaming
/// from Firestore) once you want these live instead of seeded.
enum AlertCategory { heatAlert, routeUpdate, system, weather, savedRoute, newFeature }

class NotificationAlert {
  const NotificationAlert({
    required this.id,
    required this.category,
    required this.title,
    required this.message,
    required this.timestamp,
    this.isUnread = true,
  });

  final String id;
  final AlertCategory category;
  final String title;
  final String message;
  final DateTime timestamp;
  final bool isUnread;

  NotificationAlert copyWith({bool? isUnread}) {
    return NotificationAlert(
      id: id,
      category: category,
      title: title,
      message: message,
      timestamp: timestamp,
      isUnread: isUnread ?? this.isUnread,
    );
  }
}

import 'package:MasarKKU/features/notification/presentation/widgets/notification_alert.dart';
import 'package:flutter/material.dart';

class NotificationCard extends StatelessWidget {
  const NotificationCard({
    super.key,
    required this.alert,
    this.onTap,
    this.onDismiss,
  });

  final NotificationAlert alert;

  /// Fires when the card is tapped — wired to mark-as-read.
  final VoidCallback? onTap;

  /// Fires when the dismiss (×) control is tapped — only shown once the
  /// alert is read, matching the screenshots (unread alerts show a green
  /// dot instead).
  final VoidCallback? onDismiss;

  @override
  Widget build(BuildContext context) {
    final style = _styles[alert.category]!;
    return Material(
      color: style.cardBg,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: style.iconBg,
                  shape: BoxShape.circle,
                ),
                child: Icon(style.icon, color: style.iconColor, size: 19),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: style.tagBg,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            style.label,
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700,
                              color: style.tagText,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _relativeTime(alert.timestamp),
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.grey[500],
                          ),
                        ),
                        const Spacer(),
                        if (alert.isUnread)
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Color(0xFF2E8B4F),
                              shape: BoxShape.circle,
                            ),
                          )
                        else if (onDismiss != null)
                          InkWell(
                            onTap: onDismiss,
                            borderRadius: BorderRadius.circular(10),
                            child: Icon(
                              Icons.close_rounded,
                              size: 16,
                              color: Colors.grey[400],
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      alert.title,
                      style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      alert.message,
                      style: TextStyle(
                        fontSize: 12.5,
                        color: style.bodyColor,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _relativeTime(DateTime time) {
  final diff = DateTime.now().difference(time);
  if (diff.inMinutes < 1) return 'Just now';
  if (diff.inMinutes < 60)
    return '${diff.inMinutes} min${diff.inMinutes == 1 ? '' : 's'} ago';
  if (diff.inHours < 24)
    return '${diff.inHours} hr${diff.inHours == 1 ? '' : 's'} ago';
  if (diff.inDays == 1) return 'Yesterday';
  return '${diff.inDays} days ago';
}

class _CategoryStyle {
  const _CategoryStyle({
    required this.label,
    required this.tagBg,
    required this.tagText,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.cardBg,
    required this.bodyColor,
  });

  final String label;
  final Color tagBg;
  final Color tagText;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final Color cardBg;
  final Color bodyColor;
}

// Best-effort read of the screenshot's palette per category — nudge any
// of these if they don't match your eye exactly.
const Map<AlertCategory, _CategoryStyle> _styles = {
  AlertCategory.heatAlert: _CategoryStyle(
    label: 'Heat Alert',
    tagBg: Color(0xFFFFE1DE),
    tagText: Color(0xFFE0574C),
    icon: Icons.thermostat_rounded,
    iconColor: Color(0xFFE0574C),
    iconBg: Colors.white,
    cardBg: Color(0xFFFFF3F1),
    bodyColor: Color(0xFFC1483C),
  ),
  AlertCategory.routeUpdate: _CategoryStyle(
    label: 'Route Update',
    tagBg: Color(0xFFDCE6FF),
    tagText: Color(0xFF4C6FE0),
    icon: Icons.alt_route_rounded,
    iconColor: Color(0xFF4C6FE0),
    iconBg: Colors.white,
    cardBg: Color(0xFFFFF9EC),
    bodyColor: Color(0xFF9A7B2E),
  ),
  AlertCategory.system: _CategoryStyle(
    label: 'System',
    tagBg: Color(0xFFDFF5E3),
    tagText: Color(0xFF2E8B4F),
    icon: Icons.check_circle_rounded,
    iconColor: Colors.white,
    iconBg: Color(0xFF2E8B4F),
    cardBg: Color(0xFFEFFBF1),
    bodyColor: Color(0xFF2E8B4F),
  ),
  AlertCategory.weather: _CategoryStyle(
    label: 'Weather',
    tagBg: Color(0xFFDCEBFD),
    tagText: Color(0xFF3E7FD6),
    icon: Icons.wb_cloudy_rounded,
    iconColor: Color(0xFF3E7FD6),
    iconBg: Colors.white,
    cardBg: Color(0xFFF2F7FF),
    bodyColor: Color(0xFF3E6FB0),
  ),
  AlertCategory.savedRoute: _CategoryStyle(
    label: 'Saved Route',
    tagBg: Color(0xFFEFE6DC),
    tagText: Color(0xFF8A6B4A),
    icon: Icons.bookmark_rounded,
    iconColor: Color(0xFF8A6B4A),
    iconBg: Colors.white,
    cardBg: Color(0xFFFAF6F1),
    bodyColor: Color(0xFF7A6450),
  ),
  AlertCategory.newFeature: _CategoryStyle(
    label: 'New Feature',
    tagBg: Color(0xFFF1E1F7),
    tagText: Color(0xFF9B4FC7),
    icon: Icons.auto_awesome_rounded,
    iconColor: Color(0xFF9B4FC7),
    iconBg: Colors.white,
    cardBg: Color(0xFFFAF2FD),
    bodyColor: Color(0xFF8A4BAE),
  ),
};
